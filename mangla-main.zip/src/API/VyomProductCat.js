
const VyomProductCat = [
    { 
        id: 1,
        maintitle : "Essential Oils",
        img : "../images/domestic/backgroundImg.png",
        
    },

    {
        id: 2,
        maintitle : "Diffusers",
        img : "../images/domestic/backgroundImg.png",
       
    },

    {
        id: 3,
        maintitle : "Scented Candles",
        img : "../images/domestic/backgroundImg.png",
       
    },

    {
        id: 4,
        maintitle : "Agarbatti",
        img : "../images/domestic/backgroundImg.png",
        
    },
]

export default VyomProductCat;