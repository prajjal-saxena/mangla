export const DomesticCategory = [
    { 
        id: 1,
        maintitle : "Agarbatti",
        img : "../images/domestic/backgroundImg.png",
        productall : [
            {
                id: 1,
                img : "../images/domestic/item.png",
                title : "Rohit Agarbatti",
                description: "Gulab Incense Stick is manufactured using a secret recipe of our in-house perfumery and agarbatti manufacturing that offers a natural rose fragrance.It has an enchanting fragrance of rose petals.Agarbattis honoring the purpose of aromatherapy makes you experience connectedness to the beautiful Mother Nature",
                desc2 : [{
                      id : "1",
                      weight : "12 gms",
                      price : "Rs. 15"
                   },
                   {
                        id : "2",
                        weight : "25 gms",
                        price : "Rs. 20"
                   },
                   {
                        id : "3",
                        weight : "60 gms",
                        price : "Rs. 35"
                    },
                    {
                        id : "4",
                        weight : "160 gms",
                        price : "Rs. 30"
                    }
                ],
                desc3 : "Rs. 15"
            },

            {
                id: 2,
                title : "Domestic Products",
                img : "../images/domestic/item.png",
                desc1 : "Rohit Agarbatti",
                description: "Gulab Incense Stick is manufactured using a secret recipe of our in-house perfumery and agarbatti manufacturing that offers a natural rose fragrance.It has an enchanting fragrance of rose petals.Agarbattis honoring the purpose of aromatherapy makes you experience connectedness to the beautiful Mother Nature",
                desc2 : [{
                      id : "1",
                      weight : "12 gms",
                      price : "Rs. 15"
                   },
                   {
                        id : "2",
                        weight : "25 gms",
                        price : "Rs. 20"
                   },
                   {
                        id : "3",
                        weight : "60 gms",
                        price : "Rs. 35"
                    },
                    {
                        id : "4",
                        weight : "160 gms",
                        price : "Rs. 30"
                    }
                ],
                desc3 : "Rs. 15"
            },
            {
                id: 3,
                title : "Domestic Products",
                img : "../images/domestic/item.png",
                desc1 : "Rohit Agarbatti",
                description: "Gulab Incense Stick is manufactured using a secret recipe of our in-house perfumery and agarbatti manufacturing that offers a natural rose fragrance.It has an enchanting fragrance of rose petals.Agarbattis honoring the purpose of aromatherapy makes you experience connectedness to the beautiful Mother Nature",
                desc2 : [{
                      id : "1",
                      weight : "12 gms",
                      price : "Rs. 15"
                   },
                   {
                        id : "2",
                        weight : "25 gms",
                        price : "Rs. 20"
                   },
                   {
                        id : "3",
                        weight : "60 gms",
                        price : "Rs. 35"
                    },
                    {
                        id : "4",
                        weight : "160 gms",
                        price : "Rs. 30"
                    }
                ],
                desc3 : "Rs. 15"
            }
        ]
    },

    {
        id: 2,
        maintitle : "Dhoop",
        img : "../images/domestic/backgroundImg.png",
        productall : [
            {
                id: 1,
                img : "../images/domestic/item.png",
                title : "Rohit Agarbatti",
                description: "Gulab Incense Stick is manufactured using a secret recipe of our in-house perfumery and agarbatti manufacturing that offers a natural rose fragrance.It has an enchanting fragrance of rose petals.Agarbattis honoring the purpose of aromatherapy makes you experience connectedness to the beautiful Mother Nature",
                desc2 : [{
                      id : "1",
                      weight : "12 gms",
                      price : "Rs. 15"
                   },
                   {
                        id : "2",
                        weight : "25 gms",
                        price : "Rs. 20"
                   },
                   {
                        id : "3",
                        weight : "60 gms",
                        price : "Rs. 35"
                    },
                    {
                        id : "4",
                        weight : "160 gms",
                        price : "Rs. 30"
                    }
                ],
                desc3 : "Rs. 15"
            },

            {
                id: 2,
                title : "Domestic Products",
                img : "../images/domestic/item.png",
                desc1 : "Rohit Agarbatti",
                description: "Gulab Incense Stick is manufactured using a secret recipe of our in-house perfumery and agarbatti manufacturing that offers a natural rose fragrance.It has an enchanting fragrance of rose petals.Agarbattis honoring the purpose of aromatherapy makes you experience connectedness to the beautiful Mother Nature",
                desc2 : [{
                      id : "1",
                      weight : "12 gms",
                      price : "Rs. 15"
                   },
                   {
                        id : "2",
                        weight : "25 gms",
                        price : "Rs. 20"
                   },
                   {
                        id : "3",
                        weight : "60 gms",
                        price : "Rs. 35"
                    },
                    {
                        id : "4",
                        weight : "160 gms",
                        price : "Rs. 30"
                    }
                ],
                desc3 : "Rs. 15"
            },
            {
                id: 3,
                title : "Domestic Products",
                img : "../images/domestic/item.png",
                desc1 : "Rohit Agarbatti",
                description: "Gulab Incense Stick is manufactured using a secret recipe of our in-house perfumery and agarbatti manufacturing that offers a natural rose fragrance.It has an enchanting fragrance of rose petals.Agarbattis honoring the purpose of aromatherapy makes you experience connectedness to the beautiful Mother Nature",
                desc2 : [{
                      id : "1",
                      weight : "12 gms",
                      price : "Rs. 15"
                   },
                   {
                        id : "2",
                        weight : "25 gms",
                        price : "Rs. 20"
                   },
                   {
                        id : "3",
                        weight : "60 gms",
                        price : "Rs. 35"
                    },
                    {
                        id : "4",
                        weight : "160 gms",
                        price : "Rs. 30"
                    }
                ],
                desc3 : "Rs. 15"
            }
        ]
    },

    {
        id: 3,
        maintitle : "Hawan Samagri",
        img : "../images/domestic/backgroundImg.png",
        productall : [
            {
                id: 1,
                img : "../images/domestic/item.png",
                title : "Rohit Agarbatti",
                description: "Gulab Incense Stick is manufactured using a secret recipe of our in-house perfumery and agarbatti manufacturing that offers a natural rose fragrance.It has an enchanting fragrance of rose petals.Agarbattis honoring the purpose of aromatherapy makes you experience connectedness to the beautiful Mother Nature",
                desc2 : [{
                      id : "1",
                      weight : "12 gms",
                      price : "Rs. 15"
                   },
                   {
                        id : "2",
                        weight : "25 gms",
                        price : "Rs. 20"
                   },
                   {
                        id : "3",
                        weight : "60 gms",
                        price : "Rs. 35"
                    },
                    {
                        id : "4",
                        weight : "160 gms",
                        price : "Rs. 30"
                    }
                ],
                desc3 : "Rs. 15"
            },

            {
                id: 2,
                title : "Domestic Products",
                img : "../images/domestic/item.png",
                desc1 : "Rohit Agarbatti",
                description: "Gulab Incense Stick is manufactured using a secret recipe of our in-house perfumery and agarbatti manufacturing that offers a natural rose fragrance.It has an enchanting fragrance of rose petals.Agarbattis honoring the purpose of aromatherapy makes you experience connectedness to the beautiful Mother Nature",
                desc2 : [{
                      id : "1",
                      weight : "12 gms",
                      price : "Rs. 15"
                   },
                   {
                        id : "2",
                        weight : "25 gms",
                        price : "Rs. 20"
                   },
                   {
                        id : "3",
                        weight : "60 gms",
                        price : "Rs. 35"
                    },
                    {
                        id : "4",
                        weight : "160 gms",
                        price : "Rs. 30"
                    }
                ],
                desc3 : "Rs. 15"
            },
            {
                id: 3,
                title : "Domestic Products",
                img : "../images/domestic/item.png",
                desc1 : "Rohit Agarbatti",
                description: "Gulab Incense Stick is manufactured using a secret recipe of our in-house perfumery and agarbatti manufacturing that offers a natural rose fragrance.It has an enchanting fragrance of rose petals.Agarbattis honoring the purpose of aromatherapy makes you experience connectedness to the beautiful Mother Nature",
                desc2 : [{
                      id : "1",
                      weight : "12 gms",
                      price : "Rs. 15"
                   },
                   {
                        id : "2",
                        weight : "25 gms",
                        price : "Rs. 20"
                   },
                   {
                        id : "3",
                        weight : "60 gms",
                        price : "Rs. 35"
                    },
                    {
                        id : "4",
                        weight : "160 gms",
                        price : "Rs. 30"
                    }
                ],
                desc3 : "Rs. 15"
            }
        ]
    },

    {
        id: 4,
        maintitle : "Pooja Samagri",
        img : "../images/domestic/backgroundImg.png",
        productall : [
            {
                id: 1,
                img : "../images/domestic/item.png",
                title : "Rohit Agarbatti",
                description: "Gulab Incense Stick is manufactured using a secret recipe of our in-house perfumery and agarbatti manufacturing that offers a natural rose fragrance.It has an enchanting fragrance of rose petals.Agarbattis honoring the purpose of aromatherapy makes you experience connectedness to the beautiful Mother Nature",
                desc2 : [{
                      id : "1",
                      weight : "12 gms",
                      price : "Rs. 15"
                   },
                   {
                        id : "2",
                        weight : "25 gms",
                        price : "Rs. 20"
                   },
                   {
                        id : "3",
                        weight : "60 gms",
                        price : "Rs. 35"
                    },
                    {
                        id : "4",
                        weight : "160 gms",
                        price : "Rs. 30"
                    }
                ],
                desc3 : "Rs. 15"
            },

            {
                id: 2,
                title : "Domestic Products",
                img : "../images/domestic/item.png",
                desc1 : "Rohit Agarbatti",
                description: "Gulab Incense Stick is manufactured using a secret recipe of our in-house perfumery and agarbatti manufacturing that offers a natural rose fragrance.It has an enchanting fragrance of rose petals.Agarbattis honoring the purpose of aromatherapy makes you experience connectedness to the beautiful Mother Nature",
                desc2 : [{
                      id : "1",
                      weight : "12 gms",
                      price : "Rs. 15"
                   },
                   {
                        id : "2",
                        weight : "25 gms",
                        price : "Rs. 20"
                   },
                   {
                        id : "3",
                        weight : "60 gms",
                        price : "Rs. 35"
                    },
                    {
                        id : "4",
                        weight : "160 gms",
                        price : "Rs. 30"
                    }
                ],
                desc3 : "Rs. 15"
            },
            {
                id: 3,
                title : "Domestic Products",
                img : "../images/domestic/item.png",
                desc1 : "Rohit Agarbatti",
                description: "Gulab Incense Stick is manufactured using a secret recipe of our in-house perfumery and agarbatti manufacturing that offers a natural rose fragrance.It has an enchanting fragrance of rose petals.Agarbattis honoring the purpose of aromatherapy makes you experience connectedness to the beautiful Mother Nature",
                desc2 : [{
                      id : "1",
                      weight : "12 gms",
                      price : "Rs. 15"
                   },
                   {
                        id : "2",
                        weight : "25 gms",
                        price : "Rs. 20"
                   },
                   {
                        id : "3",
                        weight : "60 gms",
                        price : "Rs. 35"
                    },
                    {
                        id : "4",
                        weight : "160 gms",
                        price : "Rs. 30"
                    }
                ],
                desc3 : "Rs. 15"
            }
        ]
    },
]