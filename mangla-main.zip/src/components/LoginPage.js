import React from 'react'
import {RiLockPasswordFill} from 'react-icons/ri'
import {FcGoogle} from 'react-icons/fc';
import {GrFacebookOption} from 'react-icons/gr';
import {FaTwitter} from 'react-icons/fa';
import {GrClose} from 'react-icons/gr';
import {FaUserAlt} from 'react-icons/fa';
import styled from 'styled-components';


const LoginPage = () => {
  return (
     <p>Our tEam</p>
  )
}

const Wrapper = styled.section`

`

export default LoginPage