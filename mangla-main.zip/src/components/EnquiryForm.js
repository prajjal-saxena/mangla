import React from 'react'

const EnquiryForm = () => {
  return (
    <div>EnquiryForm</div>
  )
}

export default EnquiryForm